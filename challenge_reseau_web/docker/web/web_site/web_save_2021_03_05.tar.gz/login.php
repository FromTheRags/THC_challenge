<?php

session_start();

if(!isset($_POST['login']) || !isset($_POST['password']))
{
    $error = 'Bad request';
    goto end;
}

$login = $_POST['login'];
$password = $_POST['password'];

$stm = $pdo->query("SELECT UserId FROM Users WHERE Login = '" . $login . "' AND Password = '" . $password . "'");

if($stm->rowCount() == 0)
{
    $error = 'Access denied'; // wrong login or password
    goto end;
}

$row = $stm->fetch(PDO::FETCH_ASSOC);

$_SESSION['signed_in'] = true;
$_SESSION['user_id'] = $row['UserId'];
$_SESSION['user_login'] = $login;

header('Location: index.php');
exit();

end:

?>

<html>

<head>
    <meta charset="utf-8">
    <title>PictureParadise - Sign in</title>
</head>

<body>
	<h1>PictureParadise</h1>
	<form id="sign-in-form">
		<h2>Please, sign in</h2>

		<label for="sign-in-login">Login</label>
		<input id="sign-in-login" type="text" placeholder="Type your login" name="login" required>

		<label for="sign-in-password">Password</label>
		<input id="sign-in-password" type="password" placeholder="Type your password" name="password" required>

		<p><?php if(isset($error)) echo $error; ?></p>

                <button type="submit">Sign in</button>
	</form>
</body>

</html>

