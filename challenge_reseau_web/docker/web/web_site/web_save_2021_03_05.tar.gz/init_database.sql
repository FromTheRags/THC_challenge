CREATE DATABASE IF NOT EXISTS PictureParadise;

USE PictureParadise;

DROP TABLE IF EXISTS Users;
CREATE TABLE IF NOT EXISTS Users (
	UserId INT NOT NULL AUTO_INCREMENT,
	Login VARCHAR(255) NOT NULL,
	Password VARCHAR(255) NOT NULL,
	PRIMARY KEY (UserId)
);

INSERT INTO Users(Login, Password) VALUES ('admin', 'Pa$$w0rd');
INSERT INTO Users(Login, Password) VALUES ('tom', 'jerry');
INSERT INTO Users(Login, Password) VALUES ('jerry', 'tom');

