<?php

if( isset( $_POST[ 'Upload' ] ) ) {
        $target_path  = "uploads/";
        $target_path .= basename( $_FILES[ 'uploaded' ][ 'name' ] );

        $uploaded_name = $_FILES[ 'uploaded' ][ 'name' ];
        $uploaded_ext  = substr( $uploaded_name, strrpos( $uploaded_name, '.' ) + 1);
        $uploaded_size = $_FILES[ 'uploaded' ][ 'size' ];
        $uploaded_tmp  = $_FILES[ 'uploaded' ][ 'tmp_name' ];


	if( ( strtolower( $uploaded_ext ) == "jpg" || strtolower( $uploaded_ext ) == "jpeg" || strtolower( $uploaded_ext ) == "png" ) && ( $uploaded_size < 100000 ) && getimagesize( $uploaded_tmp ) ) {
                if( !move_uploaded_file( $uploaded_tmp, $target_path ) ) {
                        $error = 'Your image was not uploaded.';
                }
                else {
			$error = "{$target_path} succesfully uploaded!";
			chmod($target_path, 0755);
                }
        }
        else {
                $error = 'Your image was not uploaded. We can only accept JPEG or PNG images.';
        }
}

?>

<h1>Upload image</h1>
<form enctype="multipart/form-data" action="#" method="POST">
	<input type="hidden" name="MAX_FILE_SIZE" value="100000" />
	Choose an image to upload:<br /><br />
	<input name="uploaded" type="file" /><br />
	<br />
	<input type="submit" name="Upload" value="Upload" />
	<pre><?php if(isset($error)) echo $error; ?></pre>
</form>

