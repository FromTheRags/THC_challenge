<?php

session_start();

if(isset($_GET['sign_out']))
{
	$_SESSION = array();
}

if(!isset($_SESSION['signed_in']) || !$_SESSION['signed_in'])
{
	header("Location: login.php");
	exit();
}

?>

<html>

<header>
	<meta charset="utf-8" />
	<title>PictureParadise</title>
</header>

<body>
<?php
	if(!isset($_GET['page']))
	{
		require_once("home.php");
	}

	if(str_contains($_GET['page'], ".."))
	{
		echo "<p>Error, unknown page</p>";
	}

	$path = "/var/www/localhost/htdocs/TEST/" . $_GET['page'];

	if(!file_exists($path))
	{
		echo "<p>Error, unknown page</p>";
	}

	require_once($_GET['page'] . ".php");
?>
	<footer>
		<form action="" method="GET">
			<input type="hidden" name="sign_out" value="true" />
			<button type="submit"></button>
		</form>
	</footer>
</body>

</html>
