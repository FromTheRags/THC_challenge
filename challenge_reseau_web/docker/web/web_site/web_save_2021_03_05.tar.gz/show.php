<?php

$login = $_SESSION['user_login'];

$picture_dir_path = "/var/www/localhost/htdocs/TEST/uploads/" . $_SESSION['user_login'] . "/";

$picture_dir_iter = new DirectoryIterator($picture_dir_path);
foreach ($picture_dir_iter as $picture_file)
{
	if (!$picture_file->isDot())
	{
		$picture_file_name = $picture_file->getFilename();
		$picture_file_path = $picture_dir_path . $picture_file_name;
		$picture_type = pathinfo($picture_file_path, PATHINFO_EXTENSION);
		$picture_data = file_get_contents($picture_file_path);
		$picture_base64 = "data:image/" . $picture_type . ";base64," . base64_encode($picture_data);
		
		echo "<img style=\"width:50px; height:50px;\" src=\"" . $picture_base64 . "\"></img>\n";
	}
}

?>

