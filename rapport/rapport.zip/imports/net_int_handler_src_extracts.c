typedef struct  __attribute__((__packed__))interface
{
    char name[NAME_SIZE];
    char *ip; //taille variable selon v4 or v6
    void (*turnOn)(struct interface*);
} Interface;

Interface* newInterface(char* name,char *ip, void (*on)(struct interface*))
{
    Interface* inter = malloc(sizeof(Interface));
    strncpy(inter->name, name, NAME_SIZE);
    inter->ip=strndup(ip, strlen(ip));
    inter->turnOn=on;
    return inter;
}

void showInterface(Interface *i)
{
    printf("\n name: %s ip: %s turnOn: %p \n",i->name,i->ip, &i->turnOn);
}