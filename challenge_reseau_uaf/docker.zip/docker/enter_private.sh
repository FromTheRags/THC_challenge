#!/bin/sh

sudo docker exec -it private_container /bin/bash

