#!/bin/sh

sudo service docker start

