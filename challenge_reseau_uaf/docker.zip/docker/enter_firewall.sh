#!/bin/sh

sudo docker exec -it firewall_container /bin/bash

