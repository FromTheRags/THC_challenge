#!/bin/sh

sh kill_network.sh
sh delete_network.sh
sh build_network.sh
sh start_network.sh

