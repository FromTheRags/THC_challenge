#!/bin/sh

sudo docker exec -it ftp_container /bin/bash

