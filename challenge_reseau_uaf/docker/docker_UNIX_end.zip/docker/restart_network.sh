#!/bin/sh

sh stop_network.sh
sh start_network.sh

