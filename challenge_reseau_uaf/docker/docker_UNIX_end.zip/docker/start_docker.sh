#!/bin/sh

service docker start

